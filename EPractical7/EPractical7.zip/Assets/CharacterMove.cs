using UnityEngine;

public class CharacterMove : MonoBehaviour
{
    public float speed = 3f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal"); // A/D or Arrow keys
        float v = Input.GetAxis("Vertical");   // W/S or Arrow keys

        Vector3 move = new Vector3(h, 0, v);
        transform.Translate(move * speed * Time.deltaTime);
    }
}
