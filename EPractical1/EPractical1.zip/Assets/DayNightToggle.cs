﻿using UnityEngine;
using UnityEngine.InputSystem;

public class DayNightToggle : MonoBehaviour
{
    public Light directionalLight;

    [Header("Skyboxes")]
    public Material daySkybox;
    public Material nightSkybox;

    [Header("Lighting")]
    public Color dayColor = Color.white;
    public float dayIntensity = 1.2f;

    public Color nightColor = new Color(0.2f, 0.2f, 0.5f);
    public float nightIntensity = 0.2f;

    private bool isDay = true;

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            ToggleDayNight();
        }
    }

    void ToggleDayNight()
    {
        if (isDay)
        {
            // 🌙 Night
            directionalLight.color = nightColor;
            directionalLight.intensity = nightIntensity;

            RenderSettings.skybox = nightSkybox;
            RenderSettings.ambientLight = new Color(0.05f, 0.05f, 0.1f);
        }
        else
        {
            // 🌞 Day
            directionalLight.color = dayColor;
            directionalLight.intensity = dayIntensity;

            RenderSettings.skybox = daySkybox;
            RenderSettings.ambientLight = Color.white;
        }

        DynamicGI.UpdateEnvironment(); // IMPORTANT!
        isDay = !isDay;
    }
}