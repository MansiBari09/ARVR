using UnityEngine;
using UnityEngine.InputSystem;

public class CandleToggle : MonoBehaviour
{
    public ParticleSystem flame;
    public ParticleSystem smoke;
    public Light candleLight;

    private bool isLit = true;

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            ToggleCandle();
        }
    }

    void ToggleCandle()
    {
        if (isLit)
        {
            flame.Stop();
            smoke.Stop();
            candleLight.enabled = false;
        }
        else
        {
            flame.Play();
            smoke.Play();
            candleLight.enabled = true;
        }

        isLit = !isLit;
    }
}