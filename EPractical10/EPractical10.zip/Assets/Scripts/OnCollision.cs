
using UnityEngine;

public class OnCollision : MonoBehaviour
{
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.name == "RightWall")
        {
            Debug.Log("Collided with Right Wall");
        }
        else if (collision.gameObject.name == "LeftWall")
        {
            Debug.Log("Collided with Left Wall");
        }
        else if (collision.gameObject.name == "FrontWall")
        {
            Debug.Log("Collided with Front Wall");
        }
        else if (collision.gameObject.name == "BackWall")
        {
            Debug.Log("Collided with Back Wall");
        }
    }
}