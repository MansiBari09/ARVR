using UnityEngine;

public class LampToggle : MonoBehaviour
{
    private Light LampLight;

    void Start()
    {
        LampLight = GetComponent<Light>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            LampLight.enabled = !LampLight.enabled;
        }
    }
}