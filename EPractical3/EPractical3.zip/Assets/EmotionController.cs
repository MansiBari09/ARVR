﻿using System.Diagnostics;
using UnityEngine;
using UnityEngine.InputSystem;

public class EmotionController : MonoBehaviour
{
    public Renderer characterRenderer;

    public Material neutralMat;
    public Material happyMat;
    public Material sadMat;
    public Material angryMat;

    int currentEmotion = 0;

    void Update()
    {
        if (Mouse.current.leftButton.wasPressedThisFrame)
        {
            UnityEngine.Debug.Log("Clicked"); // 👈 ADD THIS
            ChangeEmotion();
        }
    }

    void ChangeEmotion()
    {
        currentEmotion = (currentEmotion + 1) % 4;

        switch (currentEmotion)
        {
            case 0:
                characterRenderer.material = neutralMat;
                break;
            case 1:
                characterRenderer.material = happyMat;
                break;
            case 2:
                characterRenderer.material = sadMat;
                break;
            case 3:
                characterRenderer.material = angryMat;
                break;
        }
    }
}