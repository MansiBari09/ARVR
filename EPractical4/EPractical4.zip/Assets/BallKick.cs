﻿using UnityEngine;
using UnityEngine.InputSystem;

public class BallKick : MonoBehaviour
{
    public Rigidbody ballRb;
    public Transform kickDirection;

    public float slowForce = 5f;
    public float mediumForce = 15f;
    public float fastForce = 40f;
    public float superFastForce = 80f; // 👈 NEW (for key 4)

    void Update()
    {
        if (Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            UnityEngine.Debug.Log("Slow Kick");
            Kick(slowForce);
        }

        if (Keyboard.current.digit2Key.wasPressedThisFrame)
        {
            UnityEngine.Debug.Log("Medium Kick");
            Kick(mediumForce);
        }

        if (Keyboard.current.digit3Key.wasPressedThisFrame)
        {
            UnityEngine.Debug.Log("Fast Kick");
            Kick(fastForce);
        }

        // 🔥 NEW KEY (4)
        if (Keyboard.current.digit4Key.wasPressedThisFrame)
        {
            UnityEngine.Debug.Log("Super Fast Kick");
            Kick(superFastForce);
        }

        // 🛑 Stop key
        if (Keyboard.current.sKey.wasPressedThisFrame)
        {
            StopBall();
        }
    }

    void Kick(float force)
    {
        ballRb.linearVelocity = Vector3.zero;
        ballRb.angularVelocity = Vector3.zero;

        Vector3 dir = (ballRb.transform.position - kickDirection.position).normalized;

        ballRb.AddForce(dir * force, ForceMode.Impulse);
    }

    void StopBall()
    {
        ballRb.linearVelocity = Vector3.zero;
        ballRb.angularVelocity = Vector3.zero;
    }
}