﻿using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using TMPro;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float speed = 5f;
    public float jumpForce = 7f;

    [Header("UI References")]
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI gameOverText;
    public TextMeshProUGUI highScoreText;
    public Button restartButton;

    [Header("Game Settings")]
    public float fallDeathY = -5f;

    private Rigidbody2D rb;
    private Vector2 movement;
    private PlayerInputActions controls;

    private float score = 0f;
    private int highScore = 0;

    private bool isGameOver = false;
    private bool isGrounded = false;

    private float startX;

    void Awake()
    {
        controls = new PlayerInputActions();

        controls.Player.Move.performed += ctx =>
            movement = ctx.ReadValue<Vector2>();

        controls.Player.Move.canceled += ctx =>
            movement = Vector2.zero;
    }

    void OnEnable()
    {
        controls.Enable();
    }

    void OnDisable()
    {
        if (controls != null)
        {
            controls.Disable();
        }
    }

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        startX = transform.position.x;

        highScore = PlayerPrefs.GetInt("HighScore", 0);

        // Hide Game Over UI
        if (gameOverText)
            gameOverText.gameObject.SetActive(false);

        if (restartButton)
            restartButton.gameObject.SetActive(false);

        UpdateScoreUI();
    }

    void FixedUpdate()
    {
        if (isGameOver) return;

        // A and D movement
        rb.linearVelocity =
            new Vector2(movement.x * speed, rb.linearVelocity.y);
    }

    void Update()
    {
        if (isGameOver) return;

        // SPACE or W = Jump
        if ((Keyboard.current.spaceKey.wasPressedThisFrame ||
             Keyboard.current.wKey.wasPressedThisFrame)
             && isGrounded)
        {
            rb.linearVelocity =
                new Vector2(rb.linearVelocity.x, jumpForce);

            isGrounded = false;

            // Increase score after jump
            score += 10;

            UpdateScoreUI();
        }

        // S key = Fast fall
        if (Keyboard.current.sKey.isPressed)
        {
            rb.linearVelocity =
                new Vector2(rb.linearVelocity.x, -speed * 2);
        }

        // Score increases based on horizontal movement
        float distanceTraveled =
            transform.position.x - startX;

        if (distanceTraveled > score)
        {
            score = distanceTraveled;

            UpdateScoreUI();
        }

        // Game Over after falling from plank
        if (transform.position.y < fallDeathY)
        {
            TriggerGameOver();
        }
    }

    void UpdateScoreUI()
    {
        if (scoreText)
            scoreText.text =
                "Score: " + Mathf.FloorToInt(score);

        if (highScoreText)
            highScoreText.text =
                "Best: " + highScore;
    }

    void TriggerGameOver()
    {
        isGameOver = true;

        rb.linearVelocity = Vector2.zero;

        movement = Vector2.zero;

        // Save High Score
        if (Mathf.FloorToInt(score) > highScore)
        {
            highScore = Mathf.FloorToInt(score);

            PlayerPrefs.SetInt("HighScore", highScore);

            PlayerPrefs.Save();
        }

        // Show Game Over Text
        if (gameOverText)
        {
            gameOverText.gameObject.SetActive(true);

            gameOverText.text =
                "GAME OVER!\nScore: " +
                Mathf.FloorToInt(score) +
                "\nBest: " + highScore;
        }

        // Show Restart Button
        if (restartButton)
            restartButton.gameObject.SetActive(true);
    }

    // Ground Detection
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    // Restart Button Function
    public void RestartGame()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene().name
        );
    }
}