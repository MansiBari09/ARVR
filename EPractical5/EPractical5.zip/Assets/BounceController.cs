﻿using UnityEngine;

public class BounceController : MonoBehaviour
{
    public Rigidbody rb;

    public float stopTime = 5f; // 👈 USER CONTROL
    public float damping = 0.98f;

    private float timer = 0f;

    void Update()
    {
        timer += Time.deltaTime;

        // Gradually reduce bounce effect
        if (timer < stopTime)
        {
            rb.linearVelocity *= damping;
        }
        else
        {
            StopBall();
        }
    }

    void StopBall()
    {
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        // Freeze movement completely
        rb.isKinematic = true;
    }
}
